import os
import streamlit as st
import streamlit.components.v1 as components
from dotenv import load_dotenv

# Local modules
from pdf_utils import extract_text_from_pdf
from gemini_helper import (
    generate_study_summary,
    generate_mindmap,
    explain_concept,
    generate_exam_quiz,
    evaluate_viva_answer
)
from youtube_helper import search_youtube_videos

# Load environment variables
load_dotenv()

# Streamlit Page Config
st.set_page_config(
    page_title="IntelliStudy - AI Exam Copilot",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-title {
        font-size: 2.3rem;
        font-weight: 800;
        background: linear-gradient(90deg, #2563EB, #7C3AED, #DB2777);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        color: #4B5563;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border-radius: 10px;
        padding: 12px 18px;
        border-left: 4px solid #3B82F6;
        margin-bottom: 10px;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    .stTabs [data-baseweb="tab"] {
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

# Session State Initialization
if "extracted_text" not in st.session_state:
    st.session_state.extracted_text = ""
if "doc_meta" not in st.session_state:
    st.session_state.doc_meta = {}
if "quiz_data" not in st.session_state:
    st.session_state.quiz_data = []
if "user_quiz_answers" not in st.session_state:
    st.session_state.user_quiz_answers = {}
if "quiz_submitted" not in st.session_state:
    st.session_state.quiz_submitted = False
if "weak_topics" not in st.session_state:
    st.session_state.weak_topics = []

# ================= SIDEBAR =================
with st.sidebar:
    st.markdown("### 🎓 **IntelliStudy Copilot**")
    st.caption("Gen AI + RAG Semester Exam Preparation Assistant")
    st.markdown("---")

    # API Key Input
    env_gemini_key = os.getenv("GEMINI_API_KEY", "")
    gemini_key = st.text_input(
        "🔑 Gemini API Key",
        value=env_gemini_key,
        type="password",
        help="Free key from https://aistudio.google.com/"
    )
    if not gemini_key:
        st.warning("⚠️ Enter Gemini API key to activate AI features.")

    st.markdown("---")
    st.subheader("📁 Study Material Upload")

    # Sample data loader button for instant viva presentation
    if st.button("⚡ Load Sample OS Notes (Instant Demo)", use_container_width=True):
        sample_path = os.path.join(os.path.dirname(__file__), "sample_data", "sample_os_notes.txt")
        if os.path.exists(sample_path):
            with open(sample_path, "r", encoding="utf-8") as f:
                content = f.read()
                st.session_state.extracted_text = content
                st.session_state.doc_meta = {
                    "num_pages": "Text File (3 Units)",
                    "word_count": len(content.split()),
                    "status": "success",
                    "filename": "Operating Systems (Unit 2 & 3)"
                }
                st.success("Loaded Operating Systems sample notes!")

    uploaded_file = st.file_uploader(
        "Upload Syllabus / Lecture Notes (PDF or TXT)",
        type=["pdf", "txt"],
        help="Upload lecture slides, chapters, or handwritten notes PDF"
    )

    if uploaded_file is not None:
        if uploaded_file.name.endswith(".pdf"):
            with st.spinner("Extracting PDF text..."):
                text, meta = extract_text_from_pdf(uploaded_file)
                if meta.get("status") == "success":
                    st.session_state.extracted_text = text
                    meta["filename"] = uploaded_file.name
                    st.session_state.doc_meta = meta
                    st.success(f"Extracted {meta['num_pages']} pages ({meta['word_count']} words)!")
                else:
                    st.error(f"Error parsing PDF: {meta.get('error_message')}")
        else:
            text = uploaded_file.read().decode("utf-8", errors="ignore")
            st.session_state.extracted_text = text
            st.session_state.doc_meta = {
                "num_pages": "Plain Text",
                "word_count": len(text.split()),
                "status": "success",
                "filename": uploaded_file.name
            }
            st.success("Loaded text notes successfully!")

    # Document Status Card
    if st.session_state.extracted_text:
        meta = st.session_state.doc_meta
        st.markdown("---")
        st.markdown(f"""
        <div class="metric-card">
            <b>📄 Active Document:</b><br/>{meta.get('filename', 'Custom Notes')}<br/>
            <b>📊 Words:</b> {meta.get('word_count', 0):,} | <b>Pages:</b> {meta.get('num_pages', 'N/A')}
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("""
    **Project Info:**
    - **Developer:** Yuganshu Kumar
    - **University:** IILM University
    - **Semester:** 3rd Semester
    - **Domain:** Gen AI + Education API Copilot
    """)

# ================= MAIN PAGE =================
st.markdown('<div class="main-title">IntelliStudy: AI Exam & Syllabus Copilot</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Solve college semester exam preparation using Generative AI (RAG, Vision, Reasoning) and Automated Lecture Discovery APIs.</div>', unsafe_allow_html=True)

if not st.session_state.extracted_text:
    st.info("👈 **Shuru karne ke liye**: Sidebar se apni PDF / Notes upload karein ya **'Load Sample OS Notes (Instant Demo)'** button click karein.")
    st.stop()

# TABS INTERFACE
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📖 Exam Revision Kit",
    "🧠 Visual Mindmap",
    "💡 Concept Explainer (ELIF5)",
    "📝 AI Mock Quiz",
    "🎤 AI Oral Viva & Video Lectures"
])

# ----------------- TAB 1: EXAM REVISION KIT -----------------
with tab1:
    st.header("📖 High-Yield University Exam Kit")
    st.write("Generative AI scans your entire material to extract must-know academic definitions, key principles, and top-predicted exam questions.")
    
    if st.button("✨ Generate Exam Revision Kit", type="primary", key="btn_summary"):
        if not gemini_key:
            st.error("Please provide Gemini API key in sidebar.")
        else:
            with st.spinner("Analyzing document and synthesizing high-yield exam points..."):
                try:
                    summary = generate_study_summary(st.session_state.extracted_text, api_key=gemini_key)
                    st.session_state.summary_result = summary
                except Exception as e:
                    st.error(f"Error: {e}")

    if "summary_result" in st.session_state:
        st.markdown(st.session_state.summary_result)

# ----------------- TAB 2: VISUAL MINDMAP -----------------
with tab2:
    st.header("🧠 Conceptual Hierarchy Mindmap")
    st.write("Generates interactive Mermaid.js diagram representing relationships between topics.")
    
    if st.button("🕸️ Build Visual Mindmap", key="btn_mindmap"):
        if not gemini_key:
            st.error("Please provide Gemini API key in sidebar.")
        else:
            with st.spinner("Extracting semantic concept graph..."):
                try:
                    mermaid_code = generate_mindmap(st.session_state.extracted_text, api_key=gemini_key)
                    st.session_state.mermaid_code = mermaid_code
                except Exception as e:
                    st.error(f"Error: {e}")

    if "mermaid_code" in st.session_state:
        m_code = st.session_state.mermaid_code
        st.subheader("Rendered Concept Flowchart:")
        html_code = f"""
        <div class="mermaid" style="background:#FFFFFF; padding:15px; border-radius:8px; border:1px solid #E2E8F0;">
        {m_code}
        </div>
        <script type="module">
            import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs';
            mermaid.initialize({{ startOnLoad: true, theme: 'neutral' }});
        </script>
        """
        components.html(html_code, height=450, scrolling=True)
        with st.expander("View Raw Mermaid Code"):
            st.code(m_code, language="mermaid")

# ----------------- TAB 3: CONCEPT EXPLAINER -----------------
with tab3:
    st.header("💡 Feynman Concept Explainer")
    st.write("Ask any difficult concept from your syllabus. AI explains it with intuitive real-life analogies and exam definitions.")

    col_c1, col_c2 = st.columns([3, 1])
    with col_c1:
        concept_input = st.text_input("Enter Topic / Concept:", placeholder="e.g. Banker's Algorithm, Round Robin Scheduling, Convoy Effect")
    with col_c2:
        tone = st.selectbox("Explanation Style:", ["Intuitive & Analogy (ELIF5)", "Strict Academic Rigor", "Exam Diagram & Numerical"])

    if st.button("🚀 Explain with Analogy", key="btn_explain"):
        if not concept_input.strip():
            st.warning("Please type a concept name.")
        elif not gemini_key:
            st.error("Please enter Gemini API key in sidebar.")
        else:
            with st.spinner(f"Explaining '{concept_input}' using {tone}..."):
                try:
                    explanation = explain_concept(
                        concept=concept_input,
                        context=st.session_state.extracted_text,
                        tone=tone,
                        api_key=gemini_key
                    )
                    st.markdown(explanation)
                except Exception as e:
                    st.error(f"Error: {e}")

# ----------------- TAB 4: AI MOCK QUIZ -----------------
with tab4:
    st.header("📝 AI Semester Mock Quiz")
    st.write("Tests your understanding with dynamic exam questions extracted directly from your study material.")

    col_q1, col_q2 = st.columns([2, 1])
    with col_q1:
        num_q = st.slider("Number of Questions:", min_value=3, max_value=8, value=4)
    with col_q2:
        if st.button("🎯 Generate New Quiz", type="primary"):
            if not gemini_key:
                st.error("Please provide Gemini API key in sidebar.")
            else:
                with st.spinner("Creating university-level quiz questions..."):
                    try:
                        questions = generate_exam_quiz(st.session_state.extracted_text, num_questions=num_q, api_key=gemini_key)
                        st.session_state.quiz_data = questions
                        st.session_state.user_quiz_answers = {}
                        st.session_state.quiz_submitted = False
                    except Exception as e:
                        st.error(f"Error: {e}")

    if st.session_state.quiz_data:
        st.markdown("---")
        for q in st.session_state.quiz_data:
            q_id = q["id"]
            st.markdown(f"#### Q{q_id}. {q['question']}")
            selected = st.radio(
                "Options:",
                q["options"],
                key=f"quiz_opt_{q_id}",
                index=None,
                disabled=st.session_state.quiz_submitted
            )
            if selected:
                # Extract chosen letter (e.g., 'A' from 'A) ...')
                st.session_state.user_quiz_answers[q_id] = selected[0].upper()
            st.write("")

        if not st.session_state.quiz_submitted:
            if st.button("📊 Submit Quiz & Check Answers"):
                st.session_state.quiz_submitted = True
                st.rerun()
        else:
            # Score Calculation
            score = 0
            total = len(st.session_state.quiz_data)
            weak_list = []
            
            for q in st.session_state.quiz_data:
                q_id = q["id"]
                correct = q["answer"].strip().upper()
                user_choice = st.session_state.user_quiz_answers.get(q_id, "NONE")
                if user_choice == correct:
                    score += 1
                else:
                    weak_list.append(q["question"])

            st.session_state.weak_topics = weak_list

            st.success(f"### 🎉 Your Score: {score} / {total} ({(score/total)*100:.1f}%)")
            
            st.markdown("### 📋 Detailed Explanations:")
            for q in st.session_state.quiz_data:
                q_id = q["id"]
                correct = q["answer"].strip().upper()
                user_choice = st.session_state.user_quiz_answers.get(q_id, "Not Answered")
                is_correct = user_choice == correct

                badge = "✅ Correct" if is_correct else "❌ Incorrect"
                st.markdown(f"**Q{q_id}: {q['question']}** — `{badge}`")
                st.write(f"- Your Answer: `{user_choice}` | Correct Answer: `{correct}`")
                st.info(f"💡 Explanation: {q['explanation']}")
                st.write("---")

# ----------------- TAB 5: AI VIVA & YOUTUBE API -----------------
with tab5:
    st.header("🎤 AI Oral Viva & Automated YouTube Lecture Finder")
    st.write("Simulate viva voce with an AI examiner. If your score is low or you have doubts, the system automatically calls external YouTube APIs to find the best lectures for you.")

    viva_q = st.text_input(
        "Viva Question:",
        value="Explain the four necessary Coffman conditions for a Deadlock to occur.",
        help="Type or select an exam viva question"
    )

    user_ans = st.text_area(
        "Student Answer (Type your answer as you would explain in Viva):",
        placeholder="e.g. Deadlock happens when four conditions are met: Mutual exclusion, hold and wait, no preemption, and circular wait...",
        height=140
    )

    if st.button("🎓 Submit Viva Answer for Professor Grading", type="primary"):
        if not user_ans.strip():
            st.warning("Please provide your answer.")
        elif not gemini_key:
            st.error("Please enter Gemini API key in sidebar.")
        else:
            with st.spinner("AI Professor is evaluating your viva response..."):
                try:
                    eval_result = evaluate_viva_answer(
                        question=viva_q,
                        user_answer=user_ans,
                        context=st.session_state.extracted_text,
                        api_key=gemini_key
                    )
                    st.session_state.viva_eval = eval_result
                except Exception as e:
                    st.error(f"Error evaluating viva: {e}")

    if "viva_eval" in st.session_state:
        res = st.session_state.viva_eval
        score = res.get("score_out_of_10", 0)
        
        st.markdown(f"### 🏆 Professor's Score: **{score} / 10** ({res.get('accuracy_level', 'Evaluated')})")
        
        col_v1, col_v2 = st.columns(2)
        with col_v1:
            st.success(f"**👍 Accurate Points Mentioned:**\n\n{res.get('what_was_accurate', 'Good effort.')}")
        with col_v2:
            st.warning(f"**⚠️ Missing Critical Keywords / Diagrams:**\n\n{res.get('missing_critical_points', 'None.')}")

        st.markdown(f"**⭐ Model Topper Answer for Exams:**\n\n{res.get('ideal_exam_answer', '')}")

        # Smart Tool Calling: YouTube API integration for recommended topics
        topics_to_learn = res.get("recommended_topics_to_revise", [viva_q])
        st.markdown("---")
        st.subheader("📺 Targeted Video Lectures (External API Tool Call)")
        st.caption("AI identified weak concepts and called the YouTube lecture search tool:")

        for topic in topics_to_learn[:2]:
            st.markdown(f"#### 🔍 Recommended Lectures for: *{topic}*")
            with st.spinner(f"Calling Video API for '{topic}'..."):
                videos = search_youtube_videos(topic, max_results=3)
                v_cols = st.columns(len(videos))
                for i, vid in enumerate(videos):
                    with v_cols[i]:
                        if vid.get("thumbnail"):
                            st.image(vid["thumbnail"], use_column_width=True)
                        st.markdown(f"**[{vid['title']}]({vid['url']})**")
                        st.caption(f"Channel: {vid.get('channel', 'YouTube')}")
