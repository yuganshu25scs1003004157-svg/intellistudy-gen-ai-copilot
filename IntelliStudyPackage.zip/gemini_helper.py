import os
import json
import re
from typing import Dict, Any, List

def _get_api_key(api_key: str = None) -> str:
    key = api_key or os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        raise ValueError("Gemini API Key is missing. Please set GEMINI_API_KEY in .env or enter it in the sidebar.")
    return key


def call_gemini(prompt: str, json_mode: bool = False, api_key: str = None) -> str:
    """
    Calls Gemini using Google's modern google-genai SDK with automatic model
    fallback (gemini-2.5-flash -> gemini-2.0-flash -> gemini-1.5-flash).
    """
    key = _get_api_key(api_key)

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=key)
    config = None
    if json_mode:
        config = types.GenerateContentConfig(response_mime_type="application/json")

    # Priority list of current models to try automatically
    models_to_try = [
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-2.0-flash-exp",
        "gemini-2.5-pro",
        "gemini-1.5-flash-latest",
        "gemini-1.5-flash"
    ]

    last_error = None
    for model_name in models_to_try:
        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=config
            )
            if response and response.text:
                return response.text
        except Exception as e:
            err = str(e)
            # If model name not found (404), try next model
            if "404" in err or "not found" in err.lower():
                last_error = e
                continue
            # If 403 free tier or project issue
            if "403" in err and "free tier" in err.lower():
                raise Exception("403 Error: Free tier is disabled on this Google Cloud project. Google AI Studio (aistudio.google.com) par Personal Gmail ID se 'Create API Key in new project' select karein.")
            last_error = e

    # Dynamic fallback: try to discover any available model from the account
    try:
        for m in client.models.list():
            m_name = getattr(m, 'name', '') or getattr(m, 'id', '')
            if m_name and any(x in m_name.lower() for x in ['flash', 'pro']):
                # Strip 'models/' prefix if present
                clean_name = m_name.replace("models/", "")
                try:
                    response = client.models.generate_content(
                        model=clean_name,
                        contents=prompt,
                        config=config
                    )
                    if response and response.text:
                        return response.text
                except Exception:
                    continue
    except Exception:
        pass

    if last_error:
        raise last_error

    raise RuntimeError("Could not connect to any Gemini model. Please verify your API key at aistudio.google.com.")


def generate_study_summary(context: str, api_key: str = None) -> str:
    """Generates structured high-yield revision notes from uploaded content."""
    prompt = f"""
You are an expert college professor preparing your university engineering students for semester examinations.
Analyze the following course material / notes and create an organized, high-yield Exam Revision Kit.

Format the response cleanly with Markdown headings:
1. 🎯 **Core Concept Overview**: High-level essence of this subject/chapter in 2-3 sentences.
2. 🔑 **Crucial Definitions & Keywords**: Must-know terms with precise academic definitions.
3. ⚡ **Formulas / Principles / Architecture**: Key laws, workflows, algorithms, or formulas.
4. 🏆 **Top 5 Predicted University Exam Questions**: What professors love to ask from this topic.
5. 💡 **Pro Exam Tips**: Common pitfalls, diagrams to draw, and scoring advice.

Course Material / Notes:
\"\"\"
{context[:25000]}
\"\"\"
"""
    return call_gemini(prompt, json_mode=False, api_key=api_key)


def generate_mindmap(context: str, api_key: str = None) -> str:
    """Generates Mermaid.js syntax for topic visual mindmap."""
    prompt = f"""
You are an expert academic concept visualizer.
Given the following notes, generate a clean, valid Mermaid.js diagram code representing the hierarchical Mindmap / Flowchart of the concepts.

Strict Rules:
- Return ONLY the Mermaid code block starting with `graph TD` or `flowchart TD`.
- Node IDs must be simple alphanumeric strings (e.g. A, B, C1, C2).
- Node labels with special characters or spaces must be enclosed in double quotes inside brackets: e.g. A["Operating System"] --> B["Process Management"].
- Do NOT include any markdown fences (no ```mermaid or ```), just the raw mermaid code text.
- Keep the graph clean with 8 to 15 nodes max so it renders neatly.

Notes:
\"\"\"
{context[:15000]}
\"\"\"
"""
    raw = call_gemini(prompt, json_mode=False, api_key=api_key).strip()
    raw = re.sub(r"^```(mermaid)?", "", raw, flags=re.MULTILINE)
    raw = re.sub(r"```$", "", raw, flags=re.MULTILINE).strip()
    if not raw.startswith("graph ") and not raw.startswith("flowchart "):
        raw = "graph TD\n" + raw
    return raw


def explain_concept(concept: str, context: str, tone: str = "Intuitive & Analogy", api_key: str = None) -> str:
    """Explains a tricky concept using the Feynman Technique or targeted academic rigor."""
    prompt = f"""
You are an inspiring mentor and teacher.
Explain the following concept using the '{tone}' style based on the provided course material (or general academic knowledge if context is brief).

Concept to explain: **{concept}**

Context from student notes:
\"\"\"
{context[:12000]}
\"\"\"

Guidelines:
- Start with a memorable real-life analogy (e.g. kitchen, traffic, library, restaurant).
- Break down the core technical mechanism step-by-step.
- Provide a mini diagram or ASCII diagram or code snippet if relevant.
- Conclude with a 1-sentence "Exam Definition" to write for full marks in exams.
"""
    return call_gemini(prompt, json_mode=False, api_key=api_key)


def generate_exam_quiz(context: str, num_questions: int = 5, api_key: str = None) -> List[Dict[str, Any]]:
    """Generates MCQs and evaluation criteria based on uploaded notes in JSON format."""
    prompt = f"""
You are a university examiner. Create {num_questions} high-yield multiple-choice questions (MCQs) based strictly on the provided study material.
The questions should test conceptual depth, practical understanding, and edge cases.

Return STRICT JSON only, formatted as a JSON array of objects:
[
  {{
    "id": 1,
    "question": "Question text here?",
    "options": ["A) ...", "B) ...", "C) ...", "D) ..."],
    "answer": "A",
    "explanation": "Detailed explanation of why this answer is correct and others are incorrect."
  }}
]

Study Material:
\"\"\"
{context[:20000]}
\"\"\"
"""
    res_text = call_gemini(prompt, json_mode=True, api_key=api_key)
    try:
        data = json.loads(res_text)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and "questions" in data:
            return data["questions"]
        return []
    except Exception:
        match = re.search(r'\[.*\]', res_text, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        return []


def evaluate_viva_answer(question: str, user_answer: str, context: str, api_key: str = None) -> Dict[str, Any]:
    """Conducts AI Viva: Evaluates student's oral/written answer to an exam question."""
    prompt = f"""
You are a seasoned university professor conducting an oral Viva Voce / technical interview for a 3rd semester engineering student.

Context / Textbook Material:
\"\"\"
{context[:15000]}
\"\"\"

Viva Question:
\"\"\"{question}\"\"\"

Student's Answer:
\"\"\"{user_answer}\"\"\"

Evaluate the student's answer fairly and rigorously. Return STRICT JSON with this schema:
{{
  "score_out_of_10": 7,
  "accuracy_level": "Good / Fair / Needs Improvement",
  "what_was_accurate": "Key points the student explained well",
  "missing_critical_points": "Important technical keywords, diagrams, or equations the student missed",
  "ideal_exam_answer": "How a topper would answer this question in 3-4 concise points",
  "recommended_topics_to_revise": ["Topic 1", "Topic 2"]
}}
"""
    res_text = call_gemini(prompt, json_mode=True, api_key=api_key)
    try:
        return json.loads(res_text)
    except Exception:
        match = re.search(r'\{.*\}', res_text, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        return {
            "score_out_of_10": 5,
            "accuracy_level": "Evaluated",
            "what_was_accurate": "Received answer.",
            "missing_critical_points": "Refer to textbook context.",
            "ideal_exam_answer": "Please review lecture notes.",
            "recommended_topics_to_revise": [question]
        }
