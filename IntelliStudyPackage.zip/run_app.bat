@echo off
title IntelliStudy - AI Exam & Syllabus Copilot
echo ============================================================
echo   IntelliStudy: AI Exam ^& Syllabus Copilot
echo   Developer: Yuganshu Kumar
echo   College: IILM University (3rd Semester)
echo ============================================================
echo.
echo Launching IntelliStudy Web Application...
echo The app will open automatically in your browser at http://localhost:8501
echo.
"C:\Users\kumar\AppData\Local\Programs\Python\Python312\python.exe" -m streamlit run app.py
pause
