# 🎓 IntelliStudy: AI Exam & Syllabus Copilot

> **College Project Submission**  
> **Student:** Yuganshu Kumar | **University:** IILM University | **Semester:** 3rd Semester  
> **Domain:** Generative AI + Educational Tool-Calling APIs

---

## 📌 1. Real-World Problem Statement
Engineering and university students face several critical pain points before semester examinations:
1. **Information Overload**: 100+ pages of lecture slides and textbooks without clarity on what actually comes in exams.
2. **Rote Learning without Intuition**: Complex algorithmic topics (e.g., *Banker's Algorithm, Deadlocks, Paging*) lack intuitive, real-life analogies.
3. **Lack of Personalized Viva Practice**: Students struggle in oral exams (Viva Voce) because they do not know how university professors grade technical explanations.
4. **Fragmented Study Experience**: When a student gets an answer wrong, they waste hours searching for relevant video tutorials on YouTube.

**IntelliStudy** solves this by creating an end-to-end Gen AI preparation copilot that ingests study material (PDFs/notes), creates structured exam kits, conducts mock exams, grades viva responses, and automatically finds targeted video lectures for weak concepts.

---

## 🏗️ 2. System Architecture & Workflow

```mermaid
flowchart TD
    User([Student / User]) -->|Uploads PDF / Notes| PDFModule[PDF Text Extractor & Parser]
    PDFModule -->|Structured Context Chunks| AppEngine[Streamlit Core Application]
    
    subgraph GenAI [Google Gemini 1.5/2.0 Flash Engine]
        direction TB
        AppEngine -->|High-Yield Summarization Prompt| Summary[Exam Revision Kit Generator]
        AppEngine -->|Concept Hierarchy Extraction| Mindmap[Mermaid.js Mindmap Builder]
        AppEngine -->|Feynman Analogy Prompt| Explainer[Feynman Concept Explainer]
        AppEngine -->|Structured Schema JSON| Quiz[Dynamic MCQ Exam Generator]
        AppEngine -->|Professor Persona Evaluation| Viva[Viva Voce Evaluator & Scorer]
    end

    Viva -->|Identifies Weak Knowledge Areas| ToolCall[External Tool Calling Engine]
    ToolCall -->|Search Request| YouTubeAPI[YouTube Data API / Lecture Discovery]
    YouTubeAPI -->|Top Lecture Videos & Thumbnails| UI[Interactive Student Dashboard]
    Summary --> UI
    Mindmap --> UI
    Explainer --> UI
    Quiz --> UI
```

---

## 🤖 3. Core Gen AI Concepts Demonstrated (Viva Points)

Examiners look for deep Gen AI implementation. Here are the core concepts used in this project:

1. **Document Grounding & Context Ingestion (RAG Concept)**:
   - Instead of answering from generic memory, Gemini answers strictly grounded in the student's uploaded college curriculum.
2. **Structured JSON Output Enforcement**:
   - For quizzes and viva scoring, `response_mime_type: "application/json"` guarantees deterministic, parseable outputs without hallucinated formatting.
3. **Persona Prompting & Evaluative Rubrics**:
   - The AI acts as a seasoned engineering professor evaluating student oral answers against university marking rubrics (Accuracy, Missing Keywords, Ideal Topper Answer).
4. **Feynman Technique Explainer**:
   - Prompts the LLM to explain complex engineering mechanics using vivid real-world metaphors (e.g., kitchen analogies for CPU multithreading).
5. **Tool Calling & External API Augmentation**:
   - The LLM identifies semantic knowledge gaps and triggers external API requests to YouTube to bridge the student's learning deficit.

---

## 🚀 4. How to Run Locally

### Step 1: Clone / Open Project Folder
```powershell
cd "c:\Users\kumar\Downloads\GEN AI"
```

### Step 2: Install Dependencies
```powershell
python -m pip install -r requirements.txt
```

### Step 3: Configure API Key
1. Get a free Gemini API key from [Google AI Studio](https://aistudio.google.com/).
2. Copy `.env.example` to `.env` and paste your key:
   ```env
   GEMINI_API_KEY=AIzaSy...
   ```
*(Note: You can also enter the key directly in the web app sidebar!)*

### Step 4: Launch the Web App
```powershell
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 🎯 5. Examiner Viva Questions & Answers (Cheat Sheet)

**Q1: What makes this a Gen AI project rather than a traditional web application?**  
> *"Sir, a traditional web app is deterministic and relies on static databases and fixed if-else logic. In IntelliStudy, the core functionality—unstructured PDF parsing, semantic understanding, dynamic quiz generation, grading oral answers with constructive feedback, and synthesizing visual mindmaps—is performed autonomously by Google's Gemini LLM using prompt engineering and structured reasoning."*

**Q2: What is RAG and how is it used here?**  
> *"RAG stands for Retrieval-Augmented Generation. Instead of having the AI hallucinate general internet information, we extract and chunk the student's uploaded notes, feeding them as grounded context into the prompt. This ensures all exam questions and revision points adhere strictly to the college syllabus."*

**Q3: How is the external API integrated?**  
> *"When a student answers a viva question, the AI evaluates the response, assigns a score out of 10, and flags missing critical concepts. Those weak concepts are then fed into the YouTube API/Lecture Discovery service to fetch video tutorials and thumbnail previews in real-time."*

---

## 📂 6. File Structure
```
GEN AI/
├── app.py                 # Streamlit Frontend & Interactive Dashboard
├── gemini_helper.py       # Core Gen AI logic (Summarizer, Mindmap, Quiz, Viva)
├── youtube_helper.py      # YouTube API & Smart Video Search Tool
├── pdf_utils.py           # PDF Text Extraction & Preprocessing
├── requirements.txt       # Python Libraries
├── .env.example           # API Configuration Template
├── README.md              # Project Documentation & Viva Guide
└── sample_data/           # Built-in sample notes for instant 1-click testing
    └── sample_os_notes.txt
```
