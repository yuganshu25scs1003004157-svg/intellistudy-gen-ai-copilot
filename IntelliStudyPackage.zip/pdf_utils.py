import io
from typing import Tuple, Dict, Any
from pypdf import PdfReader

def extract_text_from_pdf(file_bytes_or_path) -> Tuple[str, Dict[str, Any]]:
    """
    Extracts text and metadata from a PDF file.
    Works with both file paths and BytesIO (Streamlit UploadedFile).
    """
    try:
        reader = PdfReader(file_bytes_or_path)
        num_pages = len(reader.pages)
        full_text = []

        for idx, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            if text.strip():
                full_text.append(f"--- [Page {idx + 1}] ---\n{text}")

        combined_text = "\n\n".join(full_text)
        word_count = len(combined_text.split())

        metadata = {
            "num_pages": num_pages,
            "word_count": word_count,
            "char_count": len(combined_text),
            "status": "success"
        }
        return combined_text, metadata
    except Exception as e:
        return "", {"status": "error", "error_message": str(e)}

def chunk_text(text: str, chunk_size: int = 3000, overlap: int = 300) -> list[str]:
    """
    Splits text into overlapping chunks for targeted context retrieval.
    """
    if not text:
        return []
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i + chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks
